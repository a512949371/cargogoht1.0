export default class extends think.Service{
	async cardictionlistquest(data,token){
		let result={};
		result = this.execGetWithAuth('cardictionlist',data,token);
		return result
	}
	//删除字典车辆
	async deletediccarquest(data,token){
		let result={};
		result = this.execPostWithAuth('deletediccar',data,token);
		return result
	}
	
}
