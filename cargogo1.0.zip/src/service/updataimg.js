export default class extends think.Service{
	async updataimgquest(data,token){
		let result ={};
		result = this.execPostWithAuth('updataimg',data,token);
		return result;
	}
}
