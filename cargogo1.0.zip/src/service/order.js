export default class extends think.Service{

    async selectList(e,token) {
        let result = {};
        result = await this.execGetWithAuth('orderSelectList',e,token);
        return result;
    }

    async selectOne(id,token) {
        let result = {};
        result = await this.execGetWithAuth('orderSelectOne',{
            id:id,
        },token);
        return result;
    }

    async update(e,token) {
        let result = {};
        result = await this.execPostWithAuth('orderUpdate',e,token);
        return result;
    }

    async orderSelectList(e,token) {
        let result = {};
        result = await this.execGetWithAuth('orderSelectList',e,token);
        return result;
    }

    async orderAudit(e,token){
        let result = {};
        result = await this.execPostWithAuth('orderAudit',e,token);
        return result;
    }

}
