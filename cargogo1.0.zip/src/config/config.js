// default config
module.exports = {
  port: 3002,
  workers: 1
};
