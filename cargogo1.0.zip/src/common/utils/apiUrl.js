const API_HOST = 'http://192.168.54.40:10004';
const API_HOSTe = 'http://192.168.54.29:9999/admin';
const API_10007 = API_HOSTe + ':10007';
 //const API_HOST = 'http://192.168.54.35:8088/backstage';

let options = {
    "login": API_HOSTe + "/admin/login", //登录
    "getMenusByPid": API_HOSTe + "/api/menu/getMenusByMid",//根据父id查询菜单
    "addOrUpdateMenu": API_HOSTe + "/api/menu/addOrUpdate",//新增菜单
    "getMenuById": API_HOSTe + "/api/menu/selectOne",//根据父id查询菜单
    "deletessMenus": API_HOSTe + "/api/menu/deletess",//删除菜单
    "carbrandlist": API_HOSTe + "/carBrand/page",//车辆品牌列表
    "editcarbrand": API_HOSTe + "/carBrand/edit",//车辆品牌编辑
    "deletecarbrand": API_HOSTe + "/carBrand/delete",//删除车辆品牌
    "roleSelectList": API_HOSTe + "/api/role/all",//角色列表
    'roleSave': API_HOSTe+'/api/role/save',  //新增或更新角色
    'roleDelete':API_HOSTe+'/api/role/delete',     //删除角色
    'roleSelectOne':API_HOSTe+'/api/role/selectOne',  //更新角色信息
    "staffSelectList": API_HOSTe + "/carEmployee/selectList",//员工列表
    "staffSelectOne": API_HOSTe + "/carEmployee/selectOne",//员工列表单条查询
    "staffInsert": API_HOSTe + "/carEmployee/insert",//员工新增
    "staffUpdate": API_HOSTe + "/carEmployee/update",//员工编辑
    "staffTodoSelectList":API_HOSTe+"/carOrderAssign/select",//待办事项列表
    "caristrationlist":API_HOST+"/carBrand/select",
    "carbrandlist":API_HOST+"/carBrand/page",//车辆品牌列表
    "editcarbrand":API_HOST+"/carBrand/edit",//车辆品牌编辑
    "deletecarbrand":API_HOST+"/carBrand/delete",//删除车辆品牌
    "cardictionlist":API_HOST+"/carVehicleModel/page",//车辆字典列表
    "carinfolist":API_HOST+"/carVehicle/selectList",//车辆信息列表
    "buycarfrequency":API_HOST+"/carBuyConfig/selectList",//车辆信息期数列表
    "insertbuycarfrequency":API_HOST+"/carBuyConfig/insert",//新增车辆信息期数
    "deletebuycarfrequency":API_HOST+"/carBuyConfig/delete",//删除车辆信息期数
    "isbuycarfrequency":API_HOST+"/carBuyConfig/update",//是否显示车辆信息期数
    "carinfodata":API_HOST+"/carVehicle/select",//车辆明细列表
    "updatacarinfo":API_HOST+"/admin/carVehicleInfo/update",//修改车辆明细单条数据
    "lookcarinfo":API_HOST+"/carVehicle/selectOne",//查看车辆信息
    "editcarinfo":API_HOST+"/carVehicle/update",//修改车辆信息
    "deletecarinfo":API_HOST+"/carVehicle/delete",//删除车辆信息
    "carranklist":API_HOST+"/carVehicleRank/selectList",//车辆栏目列表
    "iscarinfoindex":API_HOST+"/carVehicle/view",//车辆是否首页展示
    "brandlist":API_HOST+"/carBrand/getBrandList",//获取车辆品牌列表
    "newcardiclist":API_HOST+"/carVehicleModel/queryModelList",//新增车辆列表
    "addcardiclist":API_HOST+"/carVehicleModel/addVehicleByModel",//添加车辆
    "deletediccar":API_HOST+"/carVehicleModel/delete",//删除字典车辆
    "updataimg": API_HOST + "/api/imgUpload/upload",//图片上传接口
    
    "userSelectList": API_HOSTe + "/carUserAdmin/selectList",//用户列表
    "userSelectOne": API_HOSTe + "/carUserAdmin/selectOne",//用户列表单条查询
    "userselectOrder": API_HOSTe + "/carUserAdmin/selectOrder",//用户订单
    "userUpdate": API_HOSTe + "/carUserAdmin/update",//冻结/解冻用户接口

    "orderSelectList":API_HOSTe+"/admin/carBuyOrder/orderList",//订单列表
    "orderSelectOne":API_HOSTe+"/admin/carBuyOrder/orderInfo",//订单详情
    "orderAudit":API_HOSTe+"/admin/carBuyOrder/orderAudit",//修改审核状态
}

module.exports = {
    options: options
}
