// invoked in master
