// invoked in worker
