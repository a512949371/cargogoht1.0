module.exports = class extends think.Controller {
  async __before() {
//  let user = await this.session('user');
//  if (think.isEmpty(user)) {
//    return this.redirect('/auth/login');
//  }
  }
};
