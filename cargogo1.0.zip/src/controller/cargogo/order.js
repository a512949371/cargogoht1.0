const Base = require('./base');
const order = think.service('order');

export default class extends Base {
	async indexAction() {
		return this.display()
	}
	async buyCarListAction() {
		let pagedata = this.post()
		if (think.isEmpty(pagedata)) {
			pagedata = {
				pageNo: 1,
				pageSize: 10
			}
		} else {
			pagedata = pagedata
		}
		let result = await order.selectList(pagedata, await this.getToken());
		think.logger.info('buyCarListAction++++++++', result.body.data);
		this.assign({ 'pageInfo': result.body.data, 'q': result.body.queryModel });
		return this.display();
	}

	async escortListAction() {
		var result = {
			list: [{
				id: 1,
				name: 'test',
				status: 1
			}, {
				id: 2,
				name: 'test',
				status: 0
			}]
		}
		this.assign({ 'pageInfo': result, 'q': result.queryModel });
		return this.display();
	}

	async addOrderAction() {
		return this.display();
	}

	async selectOneAction() {
		let id = this.get('id');
		let myStatus = this.get('myStatus');
		if (id != '-1') {
			console.log('id+++++++++++', id)
			let result = await order.selectOne(id, await this.getToken());
			think.logger.info('data++++++++', result);
			this.assign({ 'e': result.body.data, 'myStatus': myStatus, 'id': id });
		}
		return this.display();
	}

	async orderListAction() {
		let id = this.get('id');
		let pageStatus = this.get('pageStatus');
		if (id != '-1') {
			console.log('id+++++++++++', id)
			let result = await order.selectOne(id, await this.getToken());
			think.logger.info('data++++++++', result);
			this.assign({ 'orderId': result.body.data.orderNo, 'pageStatus': pageStatus, 'id': id });
			this.assign({ 'pageInfo': result.body.data.carBarnInfoVoList });
		}
		return this.display()
	}

	async orderAuditAction() {
		let params = this.post();
		think.logger.info('params++++++++', params);
		let result = await order.orderAudit(params, await this.getToken());
		think.logger.info('data++++++++', result);
		return this.body = result;
	}
}
