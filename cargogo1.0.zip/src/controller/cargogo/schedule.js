const Base= require('./base');

export default class extends Base{
	async indexAction(){
		return this.display()
	}
}
