const Base= require('./base');
const user = think.service('user');

export default class extends Base{
	async indexAction(){
		return this.display()
	}
	async selectListAction(){
		let pagedata = this.post()
		if (think.isEmpty(pagedata)) {
			pagedata = {
				pageNo: 1,
				pageSize: 10
			}
		} else {
			pagedata = pagedata
		}
		let result = await user.selectList(pagedata,await this.getToken());
		think.logger.info('++++++++list', result.body.data.records);
		this.assign({ 'pageInfo': result.body.data.records, 'q': result.body.queryModel });
		return this.display()
	}

	async addOrUpdataAction(){
		let id = this.get('id');
		let myStatus=this.get('myStatus');
		if(id!='-1'){
			console.log('id+++++++++++',id)
			let result = await user.selectOne(id, await this.getToken());
			think.logger.info('data++++++++', result.body.carUserInfo);
			this.assign({ 'e': result.body.carUserInfo ,'myStatus':myStatus,'id':id});
		}
		return this.display();
	}

	async orderListAction(){
		let id = this.get('id');
		let pageStatus=this.get('pageStatus');
		this.assign({'pageStatus':pageStatus,'id':id});
		let pagedata = this.post()
		if (think.isEmpty(pagedata)) {
			pagedata = {
				pageNo: 1,
				pageSize: 10
			}
		} else {
			pagedata = pagedata
		}
		pagedata.userId=id;
		think.logger.info('++++++++pagedata', pagedata);
		let result = await user.selectOrderList(pagedata,await this.getToken());
		think.logger.info('++++++++list', result.body.data.records);
		this.assign({ 'pageInfo': result.body.data.records, 'q': result.body.queryModel });
		return this.display()
	}

	
}
