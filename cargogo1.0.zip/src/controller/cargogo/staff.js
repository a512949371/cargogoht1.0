const Base = require('./base');
const staff = think.service('staff');

export default class extends Base {
	async indexAction() {
		return this.display()
	}
	async selectListAction() {
		let pagedata = this.post()
		if (think.isEmpty(pagedata)) {
			pagedata = {
				pageNo: 1,
				pageSize: 10
			}
		} else {
			pagedata = pagedata
		}
		let result = await staff.staffSelectList(pagedata,await this.getToken());
		think.logger.info('staffSelectList++++++++', result.body.data.records);
		this.assign({ 'pageInfo': result.body.data.records, 'q': result.body.queryModel });
		return this.display();
	}

	async todoListAction() {
		let pagedata = this.post()
		if (think.isEmpty(pagedata)) {
			pagedata = {
				pageNo: 1,
				pageSize: 10
			}
		} else {
			pagedata = pagedata
		}
		let result = await staff.todoList(pagedata,await this.getToken());
		think.logger.info('todoList++++++++', result);
		this.assign({ 'pageInfo': result.body.data.records, 'q': result.body.queryModel });
		return this.display();
	}

	async addOrUpdataAction() {
		let id = this.get('id');
		let myStatus=this.get('myStatus');
		if(id!='-1'){
			console.log('id+++++++++++',id)
			let result = await staff.staffSelectOne(id, await this.getToken());
			think.logger.info('data++++++++', result.body.data);
			this.assign({ 'e': result.body.data ,'myStatus':myStatus});
		}
		return this.display();
	}

	async insertAction() {
		let params = this.post();
		params.addtime = think.datetime(new Date(),'YYYY-MM-DD HH:mm:ss');
		let token = await this.getToken();
		let result = await staff.insert(params,token);
		think.logger.info('+++++++++++++++staffInsert',result);
		if(result.status == 0) {
		  return this.redirect('addOrUpdata?id='+params.id+'&myStatus=0');
		} else {
		  return this.redirect('addOrUpdata?id='+params.id+'&myStatus=-1');
		}
	  }
	
	  async updateAction() {
		let params = this.post();
		console.log('---------params',params)
		let token = await this.getToken();
		let result = await staff.update(params,token);
		think.logger.info('+++++++++staffUpdata',result);
		if(result.status == 0) {
			return this.redirect('addOrUpdata?id='+params.id+'&myStatus=0');
		  } else {
			return this.redirect('addOrUpdata?id='+params.id+'&myStatus=-1');
		  }
	  }
}
