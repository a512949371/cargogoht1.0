const Base =require('./base');
const Cardiction = think.service('cardiction');
const fileload = think.service('fileupload');
export default class extends Base{
	async selectListAction(){
		let data = this.post();
		let token = await this.session("token");
		let order = await Cardiction.cardictionlistquest(data,token);
		console.log("order0",order.body);
		if(order.status==401){
			await this.session(null);
			return this.redirect("/auth/login");
        } else if (order.status == 404) {
            return this.redirect('/cargogo/404');
        } else if (order.status == 500) {
            return this.redirect('/cargogo/500');
        } else {
			this.assign({"pageInfo":order.body.data,queryModel:order.body.queryModel});
			return this.display()
		}
	}
	async selectoneAction(){
		return this.display()
	}
	async addoneAction(){
		return this.display()
	}
	async deletediccarAction(){
		let data = this.post();
		console.log("data2",data);
		let token = await this.session("token");
		let order = await Cardiction.deletediccarquest(data,token);
		console.log("order0",order.body);
		if(order.status==401){
			await this.session(null);
			return this.redirect("/auth/login");
        } else if (order.status == 404) {
            return this.redirect('/cargogo/404');
        } else if (order.status == 500) {
            return this.redirect('/cargogo/500');
        } else {
			return this.body=order
		}
	}
	//图片上传
	async uploadimgAction() {
		let files = this.file('FirstfileImg');
		console.log(files)
		let namedata=[];
		
//		for(let i=0;i<files.FirstfileImg.length;i++){
//			let thisfile = files.FirstfileImg[i];
//			console.log('name:'+files[i].name)
//			let img = await fileload.exec("i"+thisfile.name, thisfile)
//			console.log('img+++++++'+img);
//			namedata.push(img)
//		}
		
		let img = await fileload.uploadFile(files.name, files)
		console.log("im", img)
//		if (img.status == 0) {
//			return this.body = { status: 200, data: img.body.url, realUrl: img.body.img };
//		} else if (img.status == 403) {
//			return this.body = { status: 403, data: "无权限" };
//		} else if (img.status == 401) {
//			await this.session(null)
//			return this.redirect("/auth/login")
//		} else if (img.status == 404) {
//			return this.redirect('/operate/404');
//		} else if (img.status == 500) {
//			return this.redirect('/operate/500');
//		} else {
//			return this.body = { status: 500, data: "请求异常" };
//		}

	}
}
