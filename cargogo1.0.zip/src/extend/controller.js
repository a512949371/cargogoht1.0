let getToken=async function (){
    let token = await  this.session('token');
    // return user.token;
    return token;
}

module.exports={
    getToken:getToken
}